# TOGAFrance – Livret pratique

![Couverture TOGAFrance](../../medias/images/TOGAFrance%20-%20Couverture.png)

---

## Préface – L’image qui raconte TOGAF

Sur l’image ci-dessous – bien connue des architectes d’entreprise – deux cadres se font face :  
le premier montre des pièces enchevêtrées, désordonnées, symbolisant un État éclaté, illisible, où les réformes s'empilent sans lien ;  
le second montre les mêmes pièces, mais cette fois rangées, organisées en cercles lisibles.  

C’est là toute la promesse de TOGAF, et donc de TOGAFrance :  
**transformer le chaos en cohérence**, sans imposer un modèle unique.

![Vision TOGAFrance](../../medias/images/Togaf%20-%20Vision%20image.png)

TOGAFrance, c’est cette idée simple :  
chaque partie de la nation peut reprendre place dans un ensemble lisible, humain, et transformable.  
Non en obéissant à un plan, mais en contribuant à un cap.  

Cette image est devenue notre point de départ visuel, notre **symbole initial**.
