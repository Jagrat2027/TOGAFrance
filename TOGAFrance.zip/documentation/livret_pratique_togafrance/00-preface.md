# TOGAFrance – Practical Handbook

![TOGAFrance Cover](../../medias/images/TOGAFrance%20-%20Couverture.png)

---

## Preface – The image that explains TOGAF

In the illustration below – well known to enterprise architects – two frames face each other:  
the first shows jumbled, overlapping pieces, symbolizing a fragmented, unreadable State where reforms pile up without coherence;  
the second shows the same pieces, but now arranged, structured into clear concentric circles.

This is the entire promise of TOGAF – and therefore of TOGAFrance:  
**turning chaos into coherence**, without imposing a single model.

![TOGAFrance Vision](../../medias/images/Togaf%20-%20Vision%20image.png)

TOGAFrance is built on a simple idea:  
every part of the nation can find its place again — inside a readable, human, and transformable whole.  
Not by obeying a fixed plan, but by contributing to a common direction.

This image has become our visual starting point — our **symbolic origin**.
